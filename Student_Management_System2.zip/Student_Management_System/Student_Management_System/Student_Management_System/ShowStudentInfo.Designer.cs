﻿
namespace Student_Management_System
{
    partial class ShowStudentInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShowStudentInfo));
            this.label1 = new System.Windows.Forms.Label();
            this.tcStudentInfo = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.labelGauardianName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelId = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelJoindate = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelNumber = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.labelClass = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.labelAge = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.labelAddress = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.backBtn = new System.Windows.Forms.Button();
            this.dgvStudentMarks = new System.Windows.Forms.DataGridView();
            this.tcStudentInfo.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudentMarks)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(291, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(274, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student Information";
            // 
            // tcStudentInfo
            // 
            this.tcStudentInfo.Controls.Add(this.tabPage1);
            this.tcStudentInfo.Controls.Add(this.tabPage2);
            this.tcStudentInfo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tcStudentInfo.Location = new System.Drawing.Point(12, 52);
            this.tcStudentInfo.Name = "tcStudentInfo";
            this.tcStudentInfo.SelectedIndex = 0;
            this.tcStudentInfo.Size = new System.Drawing.Size(856, 523);
            this.tcStudentInfo.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tabPage1.Controls.Add(this.labelGauardianName);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.labelId);
            this.tabPage1.Controls.Add(this.labelName);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.labelJoindate);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.labelNumber);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.labelClass);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.labelAge);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.labelEmail);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.labelAddress);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Location = new System.Drawing.Point(4, 32);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(848, 487);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Information";
            // 
            // labelGauardianName
            // 
            this.labelGauardianName.AutoSize = true;
            this.labelGauardianName.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelGauardianName.Location = new System.Drawing.Point(255, 376);
            this.labelGauardianName.Name = "labelGauardianName";
            this.labelGauardianName.Size = new System.Drawing.Size(215, 30);
            this.labelGauardianName.TabIndex = 120;
            this.labelGauardianName.Text = "GauardianName";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(13, 376);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(222, 30);
            this.label3.TabIndex = 121;
            this.label3.Text = "Gauardian Name";
            // 
            // labelId
            // 
            this.labelId.AutoSize = true;
            this.labelId.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelId.Location = new System.Drawing.Point(200, 22);
            this.labelId.Name = "labelId";
            this.labelId.Size = new System.Drawing.Size(37, 30);
            this.labelId.TabIndex = 104;
            this.labelId.Text = "ID";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelName.Location = new System.Drawing.Point(200, 65);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(87, 30);
            this.labelName.TabIndex = 106;
            this.labelName.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(24, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 30);
            this.label5.TabIndex = 105;
            this.label5.Text = "ID";
            // 
            // labelJoindate
            // 
            this.labelJoindate.AutoSize = true;
            this.labelJoindate.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelJoindate.Location = new System.Drawing.Point(196, 331);
            this.labelJoindate.Name = "labelJoindate";
            this.labelJoindate.Size = new System.Drawing.Size(127, 30);
            this.labelJoindate.TabIndex = 118;
            this.labelJoindate.Text = "Join Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(24, 65);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 30);
            this.label6.TabIndex = 107;
            this.label6.Text = "Name";
            // 
            // labelNumber
            // 
            this.labelNumber.AutoSize = true;
            this.labelNumber.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelNumber.Location = new System.Drawing.Point(196, 198);
            this.labelNumber.Name = "labelNumber";
            this.labelNumber.Size = new System.Drawing.Size(109, 30);
            this.labelNumber.TabIndex = 108;
            this.labelNumber.Text = "Number";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(20, 331);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(127, 30);
            this.label16.TabIndex = 119;
            this.label16.Text = "Join Date";
            // 
            // labelClass
            // 
            this.labelClass.AutoSize = true;
            this.labelClass.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelClass.Location = new System.Drawing.Point(196, 285);
            this.labelClass.Name = "labelClass";
            this.labelClass.Size = new System.Drawing.Size(75, 30);
            this.labelClass.TabIndex = 116;
            this.labelClass.Text = "Class";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(20, 198);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(109, 30);
            this.label15.TabIndex = 109;
            this.label15.Text = "Number";
            // 
            // labelAge
            // 
            this.labelAge.AutoSize = true;
            this.labelAge.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelAge.Location = new System.Drawing.Point(196, 238);
            this.labelAge.Name = "labelAge";
            this.labelAge.Size = new System.Drawing.Size(62, 30);
            this.labelAge.TabIndex = 114;
            this.labelAge.Text = "Age";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(20, 285);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 30);
            this.label14.TabIndex = 117;
            this.label14.Text = "Class";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelEmail.Location = new System.Drawing.Point(200, 115);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(78, 30);
            this.labelEmail.TabIndex = 110;
            this.labelEmail.Text = "Email";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(20, 238);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 30);
            this.label13.TabIndex = 115;
            this.label13.Text = "Age";
            // 
            // labelAddress
            // 
            this.labelAddress.AutoSize = true;
            this.labelAddress.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelAddress.Location = new System.Drawing.Point(200, 155);
            this.labelAddress.Name = "labelAddress";
            this.labelAddress.Size = new System.Drawing.Size(105, 30);
            this.labelAddress.TabIndex = 112;
            this.labelAddress.Text = "Address";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(24, 115);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(78, 30);
            this.label10.TabIndex = 111;
            this.label10.Text = "Email";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(24, 155);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(105, 30);
            this.label12.TabIndex = 113;
            this.label12.Text = "Address";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.SkyBlue;
            this.tabPage2.Controls.Add(this.dgvStudentMarks);
            this.tabPage2.Location = new System.Drawing.Point(4, 32);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(848, 487);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Marks";
            // 
            // backBtn
            // 
            this.backBtn.Image = ((System.Drawing.Image)(resources.GetObject("backBtn.Image")));
            this.backBtn.Location = new System.Drawing.Point(822, 6);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(46, 40);
            this.backBtn.TabIndex = 37;
            this.backBtn.UseVisualStyleBackColor = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // dgvStudentMarks
            // 
            this.dgvStudentMarks.AllowUserToAddRows = false;
            this.dgvStudentMarks.AllowUserToDeleteRows = false;
            this.dgvStudentMarks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStudentMarks.Location = new System.Drawing.Point(6, 23);
            this.dgvStudentMarks.Name = "dgvStudentMarks";
            this.dgvStudentMarks.ReadOnly = true;
            this.dgvStudentMarks.RowHeadersWidth = 51;
            this.dgvStudentMarks.RowTemplate.Height = 29;
            this.dgvStudentMarks.Size = new System.Drawing.Size(836, 458);
            this.dgvStudentMarks.TabIndex = 1;
            // 
            // ShowStudentInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(880, 609);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.tcStudentInfo);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ShowStudentInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ShowStudentInfo";
            this.Load += new System.EventHandler(this.ShowStudentInfo_Load);
            this.LocationChanged += new System.EventHandler(this.ShowStudentInfo_LocationChanged);
            this.tcStudentInfo.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudentMarks)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tcStudentInfo;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Label labelGauardianName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelId;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelJoindate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelNumber;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label labelClass;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label labelAge;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label labelAddress;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dgvStudentMarks;
    }
}